<?php
if (!defined("ROOT_PATH"))
{
	define("ROOT_PATH", dirname(__FILE__) . '/');
}
require ROOT_PATH . 'app/config/options.inc.php';
require_once ROOT_PATH . 'app/controllers/components/pjUtil.component.php';
$_GET['controller'] = 'pjFront';
$_GET['action'] = 'pjActionDownloadFile';
require_once PJ_FRAMEWORK_PATH . 'pjObserver.class.php';
$pjObserver = pjObserver::factory();
$pjObserver->init();
?>