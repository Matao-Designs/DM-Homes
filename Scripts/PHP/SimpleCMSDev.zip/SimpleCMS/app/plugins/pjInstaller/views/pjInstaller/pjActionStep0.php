<div class="i-wrap">
	<div class="i-status i-status-error">
		<div class="i-status-icon"><abbr></abbr></div>
		<div class="i-status-txt">
			<h2>Installation error!</h2>
			<p class="t10">Product is already installed. If you need to re-install it empty <span class="bold">app/config/config.inc.php</span> file.</p>
		</div>
	</div>
	
	<div class="t20">
		<p>Need help? <a href="http://www.phpjabbers.com/contact.php" target="_blank">Contact us</a></p>
	</div>
</div>