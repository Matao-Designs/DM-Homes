<?php
if(isset($tpl['arr']))
{
	echo $tpl['arr']['section_content'];
}
?>