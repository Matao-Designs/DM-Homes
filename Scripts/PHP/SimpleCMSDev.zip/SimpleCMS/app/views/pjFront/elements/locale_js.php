<?php
if (isset($tpl['locale_arr']) && is_array($tpl['locale_arr']) && !empty($tpl['locale_arr']))
{
	if(count($tpl['locale_arr']) > 1)
	{
		?>
		<div class="scmsLocale">
			<ul class="scmsLocaleMenu"><?php
			$locale_id = $controller->pjActionGetLocale();
			foreach ($tpl['locale_arr'] as $locale)
			{
				?><li><a href="#" class="scmsSelectorLocale<?php echo $locale_id == $locale['id'] ? ' scmsLocaleFocus' : NULL; ?>" data-id="<?php echo $locale['id']; ?>" title="<?php echo pjSanitize::html($locale['title']); ?>"><img src="<?php echo PJ_INSTALL_URL . 'core/framework/libs/pj/img/flags/' . $locale['file'] ?>" alt="<?php echo htmlspecialchars($locale['title']); ?>" /></a></li><?php
			}
			?>
			</ul>
		</div>
		<?php
	}
}
?>